describe("Progress bar", function() {
    var dropdownBars, Buttons, Bars, limit, value;
    
     beforeEach(function(){
         dropdownBars = ko.observableArray([]);
         Buttons = ko.observableArray([]);
         Bars = ko.observableArray([]);
         limit = ko.observable(150);
    });

    describe('Calculate the Percent and Display Value on Load', function() {
        var dropdownBars = [1,2,3];
        var Buttons = [40,48,-43,-41];
        var Bars = [75,50,25,10];
        var output = [75,50,20,30];
        var percent = [75,40,50,10];
    
        
      

      function CaluclatePercentage(input, output) {
        it('should percentage of ' + input + ' value to give ' + output, function() {
          expect(input).toEqual(output)
        });
       }
        
        function CaluclateDisplayPercent(input, output) {
           it('should percentage of ' + input + ' equal to calculated value ' + output, function() {
              expect(input).toEqual(output)
            });
        }

      for(var x = 1; x <= Bars.length; x++) {
        CaluclatePercentage(Bars[x], output[x]);
        CaluclateDisplayPercent(output[x],percent[x]);
      }
    });

  describe("Generate Buttons", function() {
      var Buttons = [40,48,-43,-41];
      var buttoncount = 3;
    it('Button Count ' + Buttons.length + ' equal to ' + buttoncount, function() {
              expect(Buttons.length).toEqual(buttoncount)
    });
  });
    
    
    describe('Progress Bar Button Click Values ', function() {
        var ButtonInputPositive = [40,40,48,40,48,40];
        var ButtonOutputPositive = [190,190,198, 190,190];
        var ButtonInputnegative = [-41,-47,-43,-43,-47,-43];
        var ButtonOutputnegative = [109, 103, 107, 107, 103,100];
        var ButtonMixDigitsInput = [40,48,-43,-41,40,41];
        var ButtonMixDigitsOutput = [158, 206, 163, 122, 162, 203];
        var limit = 150;
        
        function AddTwoNumbers(x,y){
            return x+y;
        };
        
       function TestingPositiveDigits(input, output) {
            it('should match positive values based on input of ' + input + ' and output of ' + output, function() {
                expect(AddTwoNumbers(limit,input)).toEqual(output)
            });
           }
        function TestingNegativeDigits(input, output) {
            it('should match negative values based on input of ' + input + ' and output of ' + output, function() {
                expect(AddTwoNumbers(limit,input)).toEqual(output)
            });
           }
        function TestingMixedDigits(input, output) {
            it('should match mixed values based on input of ' + input + ' and output of ' + output, function() {
                expect(AddTwoNumbers(limit,input)).toEqual(output)
            });
           }
        
        for(var x = 1; x <= ButtonInputPositive.length; x++) {
            TestingPositiveDigits(ButtonInputPositive[x], ButtonOutputPositive[x]);
        }
        for(var x = 1; x <= ButtonInputnegative.length; x++) {
            TestingNegativeDigits(ButtonInputnegative[x], ButtonOutputnegative[x]);
        }
        for(var x = 1; x <= ButtonMixDigitsInput.length; x++) {
            TestingMixedDigits(ButtonMixDigitsInput[x], ButtonMixDigitsOutput[x]);
        }
    });
});
 
  